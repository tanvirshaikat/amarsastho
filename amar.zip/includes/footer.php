
			<div class="footer_subscribe container-fluid"><!-- footer_subscribe -->
				<div class="block_subscribe col-md-6 col-md-offset-3">
<h3 style="padding-bottom: 5px;">
					<a href="index"><img style="width: 20%;" src="img/news/news_logo.png" alt="Logo"></a>
</h3> 

				 	<p>ফ্লাট #এ-৩, বাড়ি #২১, রোড #১২<br>
ধানমন্ডি আর/এ, ঢাকা ১২০৫ <br>
ফোন: +৮৮ ০২ ৯৩৫৫১১৪<br>
মোবাইল: +৮৮ ০১৭৪৮ ৩৪৮৬২১, +৮৮ ০১৯২৬ ৬৭৭৫৪০<br>
ই-মেইল: waheedivy080@gmail.com, hhhealth2015@gmail.com</p>

	<!-- <form class="newsletter_form row" action="#" method="post">   
						<div class="col-xs-6 col-sm-10"><input placeholder="Your E-Mail" type="text" name="widget_subscribe" class="widget_subscribe"></div>
						<div class="col-xs-6 col-sm-2"><button type="submit" name="submit" class="btn large black">SIGN UP</button></div>
					</form> -->
					<div class="result"></div>
				</div>
			</div><!-- // footer_subscribe -->

			<div id="footer" class="footer container-fulid"><!-- footer -->
				

				<div class="copyright"><!-- copyright -->
					<div class="hmztop">Scroll To Top</div><!-- hmztop -->
					<div class="container">
						<div class="social_icon"><!-- social_icon -->
							<span><a href="#"><i class="fa fa-facebook"></i></a></span>
							<span><a href="#"><i class="fa fa-twitter"></i></a></span>
							<span><a href="#"><i class="fa fa-google-plus"></i></a></span>
						</div><!-- // social_icon -->
						<p>Copyrights © 2018. Developed by <a href="http://techsolutionsbd.com/">Techsolutions Bangladesh</a></p>
					</div>
				</div><!-- // copyright -->
			</div><!-- // footer -->

		</div><!-- End row -->
	</div><!-- End all_content -->

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

<!-- Javascript
–––––––––––––––––––––––––––––––––––––––––––––––––– -->
	<script type="text/javascript" src="js/modernizr.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.js"></script>
	<script type="text/javascript" src="js/isotope.js"></script>
	<script type="text/javascript" src="js/jquery.jribbble-1.0.1.ugly.js"></script>
	<script type="text/javascript" src="js/jquery.bxslider.min.js"></script>
	<script type="text/javascript" src="js/hamzh.js"></script>
</body>

</html>
