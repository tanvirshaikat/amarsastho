<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]>
<!--> <!--<![endif]-->
<html lang="en">

<!-- Mirrored from demos.ashmawi.work/html/kepler/authors.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 13 Feb 2018 04:27:56 GMT -->
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title>Authors</title>
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">

  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="img/favicon.png">


  <!-- Javascript
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <script type="text/javascript" src="js/jquery.v2.1.3.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>



</head>
<body>

  <!-- Authors Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

	<div class="all_content animsition container-fluid"><!-- all_content -->
		<div class="row">

			<div class="header"><!-- Start header -->
				<div class="top_bar"><!-- Start top_bar -->
					<div class="min_top_bar"><!-- Start min_top_bar -->
						<div class="container">
							<div class="top_nav"><!-- Start top_nav -->
								<ul>
									<li><a href="#">about me</a></li>
									<li><a href="#">contact</a></li>
									<li><a href="#">Pages</a></li>
								</ul>
							</div><!-- End top_nav -->

							<div id="top_search_ico"><!-- Start top_search_ico -->
								<div class="top_search"><!-- Start top_search -->
									<form method="get"><input type="text" placeholder="Search and hit enter..."></form>
									<i class="fa fa-search search-desktop"></i>
								</div><!-- End top_search -->

								<div id="top_search_toggle"><!-- Start top_search_toggle -->
									<div id="search_toggle_top">
									<form method="get"><input type="text" placeholder="Search and hit enter..."></form>
									</div>
									<i class="fa fa-search search-desktop"></i>
								</div><!-- End top_search_toggle -->
							</div><!-- End top_search_ico -->

							<div class="social_icon"><!-- Start social_icon -->
								<span><a href="#"><i class="fa fa-facebook"></i></a></span>
								<span><a href="#"><i class="fa fa-twitter"></i></a></span>
								<span><a href="#"><i class="fa fa-google-plus"></i></a></span>
								<span><a href="#"><i class="fa fa-youtube"></i></a></span>
								<span><a href="#"><i class="fa fa-dribbble"></i></a></span>
								<span><a href="#"><i class="fa fa-behance"></i></a></span>
								<span><a href="#"><i class="fa fa-instagram"></i></a></span>
								<span><a href="#"><i class="fa fa-vimeo-square"></i></a></span>
								<span><a href="#"><i class="fa fa-linkedin"></i></a></span>
							</div><!-- End social_icon -->
						</div>
					</div><!-- End min_top_bar -->
				</div><!-- End top_bar -->

				<div class="main_header"><!-- Start main_header -->
					<div class="container">

						<div class="logo logo_blog_layout"><!-- Start logo -->
							<!-- <h3>logo</h3> -->
							<a href="index.html"><img src="img/demo/logo.png" alt="Logo"></a>
						</div><!-- End logo -->

						<div class="nav_bar"><!-- Start nav_bar -->
							<nav id="primary_nav_wrap"><!-- Start primary_nav_wrap -->
								<ul>
								  <li class="current-menu-item"><a href="index.html">Home</a>
								    <ul>
								      <li><a href="home_2.html">home 2</a></li>
								      <li><a href="home_3.html">home 3</a></li>
								      <li><a href="home_4.html">home 4</a></li>
								      <li><a href="home_5.html">home 5</a></li>
								      <li><a href="home_6.html">home 6</a></li>
								      <li><a href="home_7.html">home 7</a></li>
								      <li><a href="home_8.html">home 8</a></li>
								      <li><a href="home_9.html">home 9</a></li>
								      <li><a href="home_10.html">News layout</a></li>
								      <li><a href="home_11.html">Portfolio layout</a></li>
								    </ul>
								  </li>
								  <li><a href="#">Pages</a>
								    <ul>
								      <li><a href="about_me.html">about me</a></li>
								      <li><a href="authors.html">Authors</a></li>
								      <li><a href="contact.html">contact</a></li>
								      <li><a href="archive.html">archive</a></li>
								      <li><a href="404.html">404</a></li>
								    </ul>
								  </li>
								  <li><a href="#">single post</a>
								    <ul>
								      <li><a href="single.html">Single</a></li>
								      <li><a href="single_full_width.html">single full Width</a></li>
								      <li><a href="single_left_sidebar.html">single left sidebar</a></li>
								      <li><a href="single_right_sidebar.html">single right sidebar</a></li>
								    </ul>
								  </li>
								  <li><a href="page.html">shortcode</a></li>
								  <li><a href="#">Category</a>
								    <ul>
								      <li><a href="#">Category 1</a></li>
								      <li><a href="#">Category 2</a></li>
								      <li><a href="#">Category 3</a></li>
								    </ul>
								  </li>

							      <li><a href="about_me.html">about me</a></li>
							      <li><a href="contact.html">contact</a></li>
								  <li><a href="#">shopping</a>
								    <ul>
								      <li><a href="shopping_page.html">shopping page</a></li>
								      <li><a href="product_page.html">product page</a></li>
								      <li><a href="shopping_cart.html">shopping cart</a></li>
								    </ul>
								  </li>
							      
								</ul>
							</nav><!-- End primary_nav_wrap -->
						</div><!-- End nav_bar -->
						
						<div class="hz_responsive"><!--button for responsive menu-->
							<div id="dl-menu" class="dl-menuwrapper">
								<button class="dl-trigger">Open Menu</button>
							<ul class="dl-menu">
							  <li class="current-menu-item"><a href="index.html">Home</a>
							    <ul class="dl-submenu">
							      <li><a href="full_width.html">full width</a>
							      	<ul class="dl-submenu">
							      		<li><a href="layout_left_sidebar.html">Lift Sidebar</a></li>
							      		<li><a href="index.html">Right Sidebar</a></li>
							      	</ul>
							      </li>
							      <li><a href="grid_layout.html">Grid Layout</a>
							      	<ul class="dl-submenu">
							      		<li><a href="grid_layout_left_sidebar.html">Left Sidebar</a></li>
							      		<li><a href="grid_layout_right_sidebar.html">Right Sidebar</a></li>
							      	</ul>
							      </li>
							      <li><a href="list_layout.html">List Layout</a>
							      	<ul class="dl-submenu">
							      		<li><a href="list_layout_left_sidebar.html">List Left Sidebar</a></li>
							      		<li><a href="list_layout_right_sidebar.html">List Right Sidebar</a></li>
							      	</ul>
							      </li>
							    </ul>
							  </li>
							  <li><a href="#">Pages</a>
							    <ul class="dl-submenu">
							      <li><a href="single.html">Single</a></li>
							      <li><a href="about_me.html">about me</a></li>
							      <li><a href="contact.html">contact</a></li>
							      <li><a href="authors.html">Authors</a></li>
							      <li><a href="page.html">shortcode</a></li>
							      <li><a href="archive.html">archive</a></li>
							      <li><a href="404.html">404</a></li>
							    </ul>
							  </li>
							  <li><a href="#">single post</a>
							    <ul class="dl-submenu">
							      <li><a href="single_full_width.html">single full Width</a></li>
							      <li><a href="single_left_sidebar.html">single left sidebar</a></li>
							      <li><a href="single_right_sidebar.html">single right sidebar</a></li>
							    </ul>
							  </li>
							  <li><a href="#">Category</a>
							    <ul class="dl-submenu">
							      <li><a href="#">Category 1</a></li>
							      <li><a href="#">Category 2</a></li>
							      <li><a href="#">Category 3</a></li>
							    </ul>
							  </li>

						      <li><a href="about_me.html">about me</a></li>
						      <li><a href="contact.html">contact</a></li>
							</ul>
							</div><!-- /dl-menuwrapper -->
						</div><!--End button for responsive menu-->
						
					</div>
				</div><!-- End main_header -->
			</div><!-- End header -->

			<div class="main_content author_list container"><!-- main_content author_list -->
				<div class="main_page col-md-8"><!-- main_page -->
					<div class="post_header"><!-- post_header -->
						<h1>Authors</h1>
						<span class="title_divider"></span>
					</div><!-- // post_header -->

					<div class="main_author"><!-- main_author -->
						<div class="authorAvatar"><!-- authorAvatar -->
							<img src="../../../ww17.hamzh.info/demo/hworih/wp-content/uploads/2015/04/photodune-11116609-beautiful-small-kid-model-with-pretty-eyes-dreaming-about-m-150x150.html" alt="Your Name">
						</div><!-- // authorAvatar -->
						<div class="authorInfo"><!-- authorInfo -->
							<h4 class="authorname">Ashmawi Sami</h4>
							<p class="authordescrption">Rapidiously communicate wireless "outside the box" thinking for front-end human outside the box" thinking for front-end human capital. Synergistically recaptiualize cross functional intellectual capital</p>

							<div class="social_icon">
								<span><a href="#"><i class="fa fa-facebook"></i></a></span>
								<span><a href="#"><i class="fa fa-twitter"></i></a></span>
								<span><a href="#"><i class="fa fa-google-plus"></i></a></span>
								<span><a href="#"><i class="fa fa-linkedin"></i></a></span>
							</div>
						</div><!-- // authorInfo -->
					</div><!-- // main_author -->

					<div class="main_author"><!-- main_author -->
						<div class="authorAvatar"><!-- authorAvatar -->
							<img src="../../../ww17.hamzh.info/demo/hworih/wp-content/uploads/2015/04/photodune-11116609-beautiful-small-kid-model-with-pretty-eyes-dreaming-about-m-150x150.html" alt="Your Name">
						</div><!-- // authorAvatar -->
						<div class="authorInfo"><!-- authorInfo -->
							<h4 class="authorname">Ashmawi Sami</h4>
							<p class="authordescrption">Rapidiously communicate wireless "outside the box" thinking for front-end human outside the box" thinking for front-end human capital. Synergistically recaptiualize cross functional intellectual capital</p>

							<div class="social_icon">
								<span><a href="#"><i class="fa fa-facebook"></i></a></span>
								<span><a href="#"><i class="fa fa-twitter"></i></a></span>
								<span><a href="#"><i class="fa fa-google-plus"></i></a></span>
								<span><a href="#"><i class="fa fa-linkedin"></i></a></span>
							</div>
						</div><!-- // authorInfo -->
					</div><!-- // main_author -->

					<div class="main_author"><!-- main_author -->
						<div class="authorAvatar"><!-- authorAvatar -->
							<img src="../../../ww17.hamzh.info/demo/hworih/wp-content/uploads/2015/04/photodune-11116609-beautiful-small-kid-model-with-pretty-eyes-dreaming-about-m-150x150.html" alt="Your Name">
						</div><!-- // authorAvatar -->
						<div class="authorInfo"><!-- authorInfo -->
							<h4 class="authorname">Ashmawi Sami</h4>
							<p class="authordescrption">Rapidiously communicate wireless "outside the box" thinking for front-end human outside the box" thinking for front-end human capital. Synergistically recaptiualize cross functional intellectual capital</p>

							<div class="social_icon">
								<span><a href="#"><i class="fa fa-facebook"></i></a></span>
								<span><a href="#"><i class="fa fa-twitter"></i></a></span>
								<span><a href="#"><i class="fa fa-google-plus"></i></a></span>
								<span><a href="#"><i class="fa fa-linkedin"></i></a></span>
							</div>
						</div><!-- // authorInfo -->
					</div><!-- // main_author -->
				</div><!-- // main_page -->

				<div class="sidebar col-md-4"><!--Start Sidebar -->
					<div class="row">
						<div class="inner_sidebar"><!-- Start inner_sidebar -->

							<div class="widget  widget_about_me"><!-- Start widget About Me -->
								<div class="about_me">
									<div class="my_pic">
										<img src="img/demo/pic-widget.png" alt="Ashmawi Sami">
									</div>
									<div class="my_name">
										<h4>Ashmawi Sami</h4>
									</div>
									<div class="my_words">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing
										 elit, sed do eiusmod tempor incididunt ut labore et
										  dolore magna aliqua. Ut enim ad minim veniam</p>
									</div>
									<div class="social_icon">
										<span><a href="#"><i class="fa fa-facebook"></i></a></span>
										<span><a href="#"><i class="fa fa-twitter"></i></a></span>
										<span><a href="#"><i class="fa fa-google-plus"></i></a></span>
										<span><a href="#"><i class="fa fa-youtube"></i></a></span>
										<span><a href="#"><i class="fa fa-dribbble"></i></a></span>
										<span><a href="#"><i class="fa fa-behance"></i></a></span>
										<span><a href="#"><i class="fa fa-instagram"></i></a></span>
										<span><a href="#"><i class="fa fa-vimeo-square"></i></a></span>
										<span><a href="#"><i class="fa fa-linkedin"></i></a></span>
									</div>
								</div>
							</div><!-- End widget About Me -->

							<div class="widget widget_search"><!-- Start widget search -->
								<h4 class="widget_title">Search</h4>
								<form>
									<input type="search" value="Search here ..." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
									<input class="button" type="submit" value="Search Now">
								</form>
							</div><!-- End widget search -->

							<div class="widget widget_recent_post"><!-- Start widget recent post -->
								<h4 class="widget_title">Recent Post</h4>
								<ul class="recent_post">

									<li>
										<figure class="widget_post_thumbnail">
											<a href="#"><img src="img/demo/wid/1.png" height="80" width="80" alt="Appropriately simplify quality imperatives"></a>
										</figure>
										<div class="widget_post_info">
											<h5><a href="#">Appropriately simplify quality imperatives</a></h5>
											<div class="post_meta">
												<span><a href="#"><i class="fa fa-comments-o"></i> 0 comments</a></span>
												<span class="date_meta"><a href="#"><i class="fa fa-calendar"></i> Mar 10, 2015</a></span>
											</div>
										</div>
									</li>

									<li>
										<figure class="widget_post_thumbnail">
											<a href="#"><img src="img/demo/wid/2.png" height="80" width="80" alt="Appropriately simplify quality imperatives"></a>
										</figure>
										<div class="widget_post_info">
											<h5><a href="#">Appropriately simplify quality imperatives</a></h5>
											<div class="post_meta">
												<span><a href="#"><i class="fa fa-comments-o"></i> 0 comments</a></span>
												<span class="date_meta"><a href="#"><i class="fa fa-calendar"></i> Mar 10, 2015</a></span>
											</div>
										</div>
									</li>

									<li>
										<figure class="widget_post_thumbnail">
											<a href="#"><img src="img/demo/wid/3.png" height="80" width="80" alt="Appropriately simplify quality imperatives"></a>
										</figure>
										<div class="widget_post_info">
											<h5><a href="#">Appropriately simplify quality imperatives</a></h5>
											<div class="post_meta">
												<span><a href="#"><i class="fa fa-comments-o"></i> 0 comments</a></span>
												<span class="date_meta"><a href="#"><i class="fa fa-calendar"></i> Mar 10, 2015</a></span>
											</div>
										</div>
									</li>

									<li>
										<figure class="widget_post_thumbnail">
											<a href="#"><img src="img/demo/wid/4.png" height="80" width="80" alt="Appropriately simplify quality imperatives"></a>
										</figure>
										<div class="widget_post_info">
											<h5><a href="#">Appropriately simplify quality imperatives</a></h5>
											<div class="post_meta">
												<span><a href="#"><i class="fa fa-comments-o"></i> 0 comments</a></span>
												<span class="date_meta"><a href="#"><i class="fa fa-calendar"></i> Mar 10, 2015</a></span>
											</div>
										</div>
									</li>
								</ul>
							</div><!-- End widget recent post -->
								
							<div class="widget widget_categories"><!-- Start widget categories -->
								<h4 class="widget_title">Categories</h4>
								<ul class="categories">
									<li><a href="#">Music <span>(5)</span></a><i class="fa fa-angle-double-right"></i></li>
									<li><a href="#">Fashion <span>(10)</span></a><i class="fa fa-angle-double-right"></i></li>
									<li><a href="#">Media <span>(5)</span></a><i class="fa fa-angle-double-right"></i></li>
									<li><a href="#">Medical <span>(10)</span></a><i class="fa fa-angle-double-right"></i></li>
									<li><a href="#">Sports <span>(5)</span></a><i class="fa fa-angle-double-right"></i></li>
									<li><a href="#">Internet <span>(10)</span></a><i class="fa fa-angle-double-right"></i></li>
									<li><a href="#">Technology <span>(6)</span></a><i class="fa fa-angle-double-right"></i></li>
								</ul>
							</div><!-- End widget categories -->
																
							<div class="widget hamzh_flickr"><!-- Start widget search -->
								<h4 class="widget_title">Flickr Photos</h4>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/1.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/2.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/3.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>


								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/4.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/5.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/6.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/7.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/8.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/9.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/10.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/11.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>

								<div class="flickr_badge_image">
									<a href="#">
										<img src="img/demo/flickr/12.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
									</a>
								</div>
							</div><!-- End widget search -->

							<div class="widget widget_slider_dribbble"><!-- Start widget recent entries -->
								<h4 class="widget_title">Dribbble Gallery</h4>
								<ul class="slid_widget_dribbble">

								</ul>
							</div><!-- End Widget Recent Entries -->
								
							<div class="widget widget_recent_comments"><!--Start widget recent comments -->
								<h4 class="widget_title">Recent comments</h4>
								<ul class="recent_post">

									<li>
										<figure class="widget_post_thumbnail">
											<a href="#"><img src="img/demo/wid/5.png" height="80" width="80" alt="Rapidiously coordinate cross-unit communities without"></a>
										</figure>
										<div class="widget_post_info">
											<strong class="comment-author"><a href="#"><i class="fa fa-user"></i> Ashmawi Sami</a></strong>
											<span class="comment-c"><a href="#">Rapidiously coordinate cross-unit communities without </a></span>
										</div>
									</li>

									<li>
										<figure class="widget_post_thumbnail">
											<a href="#"><img src="img/demo/wid/4.png" height="80" width="80" alt="Rapidiously coordinate cross-unit communities without"></a>
										</figure>
										<div class="widget_post_info">
											<strong class="comment-author"><a href="#"><i class="fa fa-user"></i> Ashmawi Sami</a></strong>
											<span class="comment-c"><a href="#">Rapidiously coordinate cross-unit communities without </a></span>
										</div>
									</li>

									<li>
										<figure class="widget_post_thumbnail">
											<a href="#"><img src="img/demo/wid/2.png" height="80" width="80" alt="Rapidiously coordinate cross-unit communities without"></a>
										</figure>
										<div class="widget_post_info">
											<strong class="comment-author"><a href="#"><i class="fa fa-user"></i> Ashmawi Sami</a></strong>
											<span class="comment-c"><a href="#">Rapidiously coordinate cross-unit communities without </a></span>
										</div>
									</li>

									<li>
										<figure class="widget_post_thumbnail">
											<a href="#"><img src="img/demo/wid/1.png" height="80" width="80" alt="Rapidiously coordinate cross-unit communities without"></a>
										</figure>
										<div class="widget_post_info">
											<strong class="comment-author"><a href="#"><i class="fa fa-user"></i> Ashmawi Sami</a></strong>
											<span class="comment-c"><a href="#">Rapidiously coordinate cross-unit communities without </a></span>
										</div>
									</li>

								</ul>
							</div><!--End widget recent comments -->
								
							<div class="widget widget_advertisement"><!-- Start widget Advertisement -->
								<h4 class="widget_title">Advertisement</h4>
								<div class="ads_wid">
									<a href="#"><img src="img/ads-300x250.png" alt="Advertisement"></a>
								</div>
							</div><!-- End Widget Advertisement -->
								
							<div class="widget widget_twitter"><!-- Start widget Latest Tweets -->
								<h4 class="widget_title">Latest Tweets</h4>
								<ul class="tweet_list">
									<li class="tweet_first tweet_odd">
										<span class="tweet_text">RT <span class="at">@</span>
											<a href="#">EnvatoStudio</a>
											How My Crappy Day Jobs Made Me a High-Earning Freelancer:
											<a href="#">studioblog.envato.com/high-earning-f…</a>
											<a href="#">pic.twitter.com/u9utuNSQEU</a>
										</span> <br>
										<span class="tweet_time">
											<a href="#" title="view tweet on twitter">about 30 minutes ago</a>
										</span>
									</li>
									<li class="tweet_even">
										<span class="tweet_text">RT <span class="at">@</span>
											<a href="#">EnvatoMarket</a>
											 Some awesome entries in our flag contest! How would you redesign the flag for Planet Earth? <a href="#">enva.to/UbB-C</a>
											 <a href="#">pic.twitter.com/XMLD6jmnkQ</a>
										</span> <br>
										<span class="tweet_time">
											<a href="#" title="view tweet on twitter">about an hour ago</a>
										</span>
									</li>
								</ul>
							</div><!-- End Widget Latest Tweets -->
								
							<div class="widget widget_login"><!-- Start widget Widget Login -->
								<h4 class="widget_title">Login</h4>
								<div class="widget_login">
									<form>
										<input type="text" value="Username" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
										<div class="widget_login_password">
											<input type="password" value="Password" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
										</div>
										<input type="submit" value="Login" class="button">
									</form>
								</div>
							</div><!-- End Widget Latest Tweets -->
								
							<div class="widget  widget_tag_cloud"><!-- Start widget tag cloud -->
								<h4 class="widget_title">Tags</h4>
								<div class="tagcloud">
									<a href="#">audio</a>
									<a href="#">dailymotion</a>
									<a href="#">Gallery</a>
									<a href="#">LightBox</a>
									<a href="#">Link</a>
									<a href="#">mp3</a>
									<a href="#">nature</a>
									<a href="#">post</a>
									<a href="#">Quote</a>
									<a href="#">slider</a>
									<a href="#">soundcloud</a>
									<a href="#">sport</a>
									<a href="#">Standard</a>
									<a href="#">Twitter</a>
									<a href="#">vimeo</a>
								</div>
							</div><!-- End widget tag cloud -->
								
						</div><!-- End inner_sidebar -->
					</div>
				</div><!--End Sidebar -->
			</div><!-- // main_content -->

			<div id="footer" class="footer container-fulid"><!-- Start footer -->
				<footer class="main_footer"><!-- Start main_footer -->
					<div class="container">
						<div class="row">

							<div class="col-sm-4"><!-- Start widget_text -->
								<div id="text-3" class="widget widget_text">
									<h4 class="widget_title">Text Widget</h4>
									<div class="textwidget">
										Here you can add any text or Here you can add any text or html snippet. Good for showing some small info or about your site. html snippet. Good for showing info or about your site.
									</div>
								</div>	
							</div><!-- End widget_text -->
							
							<div class="col-sm-4"><!-- Start widget tag cloud -->
								<div class="widget  widget_tag_cloud">
									<h4 class="widget_title">Tags</h4>
									<div class="tagcloud">
										<a href="#">audio</a>
										<a href="#">dailymotion</a>
										<a href="#">Gallery</a>
										<a href="#">LightBox</a>
										<a href="#">Link</a>
										<a href="#">mp3</a>
										<a href="#">nature</a>
										<a href="#">post</a>
										<a href="#">Quote</a>
										<a href="#">slider</a>
										<a href="#">soundcloud</a>
										<a href="#">sport</a>
										<a href="#">Standard</a>
										<a href="#">Twitter</a>
										<a href="#">vimeo</a>
									</div>
								</div>
							</div><!-- End widget tag cloud -->

							<div class="col-sm-4"><!-- Start widget flickr -->
								<div class="widget hamzh_flickr">
									<h4 class="widget_title">Flickr Photos</h4>

									<div class="flickr_badge_image">
										<a href="#">
											<img src="img/demo/flickr/1.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
										</a>
									</div>

									<div class="flickr_badge_image">
										<a href="#">
											<img src="img/demo/flickr/2.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
										</a>
									</div>

									<div class="flickr_badge_image">
										<a href="#">
											<img src="img/demo/flickr/3.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
										</a>
									</div>


									<div class="flickr_badge_image">
										<a href="#">
											<img src="img/demo/flickr/4.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
										</a>
									</div>

									<div class="flickr_badge_image">
										<a href="#">
											<img src="img/demo/flickr/5.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
										</a>
									</div>

									<div class="flickr_badge_image">
										<a href="#">
											<img src="img/demo/flickr/6.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
										</a>
									</div>

									<div class="flickr_badge_image">
										<a href="#">
											<img src="img/demo/flickr/7.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
										</a>
									</div>

									<div class="flickr_badge_image">
										<a href="#">
											<img src="img/demo/flickr/8.png" alt="A photo on Flickr" title="Halloween 2014 at Envato in Melbourne">
										</a>
									</div>

								</div>
							</div><!-- Start widget flickr -->
						</div>
					</div>
				</footer><!-- End main_footer -->

				<div class="copyright"> <!-- Start copyright -->
					<div class="hmztop">Scroll To Top</div><!-- Back top -->
					<div class="footer_logo"><!-- Start footer logo -->
						<a href="#"><img src="img/demo/footer_blog_logo.png" alt="Logo"></a>
					</div><!-- End footer logo -->
					<div class="social_icon"><!--Start social_icon -->
						<span><a href="#"><i class="fa fa-facebook"></i></a></span>
						<span><a href="#"><i class="fa fa-twitter"></i></a></span>
						<span><a href="#"><i class="fa fa-google-plus"></i></a></span>
						<span><a href="#"><i class="fa fa-youtube"></i></a></span>
						<span><a href="#"><i class="fa fa-dribbble"></i></a></span>
						<span><a href="#"><i class="fa fa-behance"></i></a></span>
						<span><a href="#"><i class="fa fa-instagram"></i></a></span>
						<span><a href="#"><i class="fa fa-vimeo-square"></i></a></span>
						<span><a href="#"><i class="fa fa-skype"></i></a></span>
						<span><a href="#"><i class="fa fa-linkedin"></i></a></span>
					</div><!--End social_icon -->
					<p>Copyrights © 2015 All Rights Reserved by <a href="#">Hamzh</a></p>
				</div><!-- End copyright --> 
			</div><!-- End footer -->

		</div><!-- End row -->
	</div><!-- End all_content -->

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

<!-- Javascript
–––––––––––––––––––––––––––––––––––––––––––––––––– -->
	<script type="text/javascript" src="js/modernizr.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.js"></script>
	<script type="text/javascript" src="js/isotope.js"></script>
	<script type="text/javascript" src="js/jquery.jribbble-1.0.1.ugly.js"></script>
	<script type="text/javascript" src="js/jquery.bxslider.min.js"></script>
	<script type="text/javascript" src="js/hamzh.js"></script>
</body>

<!-- Mirrored from demos.ashmawi.work/html/kepler/authors.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 13 Feb 2018 04:28:03 GMT -->
</html>
